# Prometheus Metrics

This document describes all Prometheus metrics exposed by the egress server on the `/metrics` endpoint.

## HTTP Request Metrics

### `zipperfly_requests_total`
**Type:** Counter
**Labels:** `status` (HTTP status code)
**Description:** Total number of HTTP requests by status code.

Example labels:
- `status="200"` - Successful requests
- `status="400"` - Bad requests
- `status="401"` - Unauthorized
- `status="404"` - Not found
- `status="410"` - Expired

**Example queries:**
```promql
# Request rate by status
rate(zipperfly_requests_total[5m])

# Total 4xx errors
sum(rate(zipperfly_requests_total{status=~"4.."}[5m]))
```

## Download Outcome Metrics

### `zipperfly_downloads_total`
**Type:** Counter
**Labels:** `status` (download outcome)
**Description:** Total number of download attempts by outcome.

Labels:
- `status="completed"` - All requested files successfully fetched and zipped
- `status="partial"` - Some files missing but download succeeded (requires `IGNORE_MISSING=true`)
- `status="failed"` - Download failed due to errors

**Example queries:**
```promql
# Download success rate
rate(zipperfly_downloads_total{status="completed"}[5m]) / rate(zipperfly_downloads_total[5m])

# Partial download rate
rate(zipperfly_downloads_total{status="partial"}[5m])

# Failed downloads
rate(zipperfly_downloads_total{status="failed"}[5m])
```

## File-Level Metrics

### `zipperfly_files_requested`
**Type:** Histogram
**Description:** Distribution of the number of files requested per download.

Buckets: 1, 5, 10, 20, 50, 100, 200, 500, 1000, 5000

**Example queries:**
```promql
# Average files per download
rate(zipperfly_files_requested_sum[5m]) / rate(zipperfly_files_requested_count[5m])

# 95th percentile of files per download
histogram_quantile(0.95, rate(zipperfly_files_requested_bucket[5m]))
```

### `zipperfly_files_success`
**Type:** Histogram
**Description:** Distribution of the number of files successfully fetched per download.

Buckets: 1, 5, 10, 20, 50, 100, 200, 500, 1000, 5000

**Example queries:**
```promql
# Average successful files per download
rate(zipperfly_files_success_sum[5m]) / rate(zipperfly_files_success_count[5m])

# Compare requested vs successful
rate(zipperfly_files_requested_sum[5m]) - rate(zipperfly_files_success_sum[5m])
```

### `zipperfly_files_fetch_total`
**Type:** Counter
**Labels:** `result` (fetch result)
**Description:** Total file fetch attempts by result.

Labels:
- `result="success"` - File successfully fetched
- `result="missing"` - File not found (counted when `IGNORE_MISSING=true`)
- `result="error"` - Fetch failed due to error

**Example queries:**
```promql
# File fetch success rate
rate(zipperfly_files_fetch_total{result="success"}[5m]) / rate(zipperfly_files_fetch_total[5m])

# Missing file rate
rate(zipperfly_files_fetch_total{result="missing"}[5m])

# Error rate per file
rate(zipperfly_files_fetch_total{result="error"}[5m])
```

### `zipperfly_missing_files_total`
**Type:** Counter
**Description:** Total count of missing files encountered across all downloads.

**Example queries:**
```promql
# Rate of missing files
rate(zipperfly_missing_files_total[5m])

# Total missing files today
increase(zipperfly_missing_files_total[24h])
```

## Performance Metrics

### `zipperfly_request_duration_seconds`
**Type:** Histogram
**Description:** Request duration in seconds (from request start to completion).

Buckets: Prometheus default (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10)

**Example queries:**
```promql
# 95th percentile latency
histogram_quantile(0.95, rate(zipperfly_request_duration_seconds_bucket[5m]))

# Average request duration
rate(zipperfly_request_duration_seconds_sum[5m]) / rate(zipperfly_request_duration_seconds_count[5m])
```

### `zipperfly_outgoing_bytes`
**Type:** Histogram
**Description:** Outgoing bytes per response (compressed ZIP size).

Buckets: Exponential from 1KB to ~32GB

**Example queries:**
```promql
# Average ZIP size
rate(zipperfly_outgoing_bytes_sum[5m]) / rate(zipperfly_outgoing_bytes_count[5m])

# Total bandwidth out
rate(zipperfly_outgoing_bytes_sum[5m])

# 95th percentile ZIP size
histogram_quantile(0.95, rate(zipperfly_outgoing_bytes_bucket[5m]))
```

### `zipperfly_incoming_bytes`
**Type:** Histogram
**Description:** Incoming bytes from storage per request (uncompressed size of all files).

Buckets: Exponential from 1KB to ~32GB

**Example queries:**
```promql
# Compression ratio
rate(zipperfly_outgoing_bytes_sum[5m]) / rate(zipperfly_incoming_bytes_sum[5m])

# Total storage bandwidth
rate(zipperfly_incoming_bytes_sum[5m])
```

## System Metrics

### `zipperfly_memory_heap_alloc_bytes`
**Type:** Gauge
**Description:** Current heap allocation in bytes (updated every 10 seconds).

**Example queries:**
```promql
# Current memory usage
zipperfly_memory_heap_alloc_bytes

# Memory usage over time
zipperfly_memory_heap_alloc_bytes[1h]
```

### `zipperfly_goroutines`
**Type:** Gauge
**Description:** Number of goroutines (updated every 10 seconds).

**Example queries:**
```promql
# Current goroutine count
zipperfly_goroutines

# Goroutine growth
rate(zipperfly_goroutines[5m])
```

## Example Dashboards

### Success Rate Panel
```promql
# Overall download success rate
sum(rate(zipperfly_downloads_total{status="completed"}[5m])) / sum(rate(zipperfly_downloads_total[5m])) * 100
```

### Missing Files Alert
```promql
# Alert if missing file rate exceeds threshold
rate(zipperfly_missing_files_total[5m]) > 0.1
```

### Performance Overview
```promql
# P50, P95, P99 latencies
histogram_quantile(0.50, rate(zipperfly_request_duration_seconds_bucket[5m]))
histogram_quantile(0.95, rate(zipperfly_request_duration_seconds_bucket[5m]))
histogram_quantile(0.99, rate(zipperfly_request_duration_seconds_bucket[5m]))
```

### Bandwidth Panel
```promql
# Outgoing bandwidth (MB/s)
rate(zipperfly_outgoing_bytes_sum[5m]) / 1024 / 1024

# Incoming bandwidth from storage (MB/s)
rate(zipperfly_incoming_bytes_sum[5m]) / 1024 / 1024
```

## Monitoring Best Practices

1. **Alert on failed downloads:** Set alerts when `zipperfly_downloads_total{status="failed"}` exceeds threshold
2. **Monitor missing files:** Track `zipperfly_missing_files_total` to detect storage issues
3. **Watch partial downloads:** High rates of `status="partial"` may indicate data integrity issues
4. **Track latency:** Set SLOs on p95/p99 of `zipperfly_request_duration_seconds`
5. **Memory monitoring:** Alert on sustained high `zipperfly_memory_heap_alloc_bytes`
6. **File fetch errors:** Monitor `zipperfly_files_fetch_total{result="error"}` for storage backend issues
