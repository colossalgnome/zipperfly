package database

import (
	"context"
	"fmt"

	"zipperfly/internal/config"
	"zipperfly/internal/metrics"
	"zipperfly/internal/models"
)

// Store defines the interface for database operations
type Store interface {
	GetRecord(ctx context.Context, id string) (*models.DownloadRecord, error)
	Close() error
}

// New creates a new database store based on the configured engine
func New(ctx context.Context, cfg *config.Config, m *metrics.Metrics) (Store, error) {
	switch cfg.DBEngine {
	case "postgres", "postgresql":
		return NewPostgresStore(ctx, cfg, m)
	case "mysql":
		return NewMySQLStore(cfg, m)
	case "redis":
		return NewRedisStore(ctx, cfg, m)
	default:
		return nil, fmt.Errorf("unsupported database engine: %s", cfg.DBEngine)
	}
}
