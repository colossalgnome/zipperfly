// +build integration

package integration

import (
	"archive/zip"
	"bytes"
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"

	"go.uber.org/zap"

	"zipperfly/internal/auth"
	"zipperfly/internal/circuitbreaker"
	"zipperfly/internal/config"
	"zipperfly/internal/database"
	"zipperfly/internal/handlers"
	"zipperfly/internal/metrics"
	"zipperfly/internal/storage"
)

const (
	fixturesDir = "../fixtures/files"
)

func TestIntegration_LocalStorage_PostgreSQL(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping integration test")
	}

	// Setup
	logger, _ := zap.NewDevelopment()
	m := metrics.New()

	cfg := &config.Config{
		DBURL:                     "postgres://zipperfly:testpass@localhost:5432/zipperfly_test?sslmode=disable",
		DBEngine:                  "postgres",
		TableName:                 "downloads",
		IDField:                   "id",
		StorageType:               "local",
		StoragePath:               getAbsPath(fixturesDir),
		EnforceSigning:            false,
		SigningSecret:             []byte("test-secret"),
		DatabaseQueryTimeout:      5 * time.Second,
		StorageFetchTimeout:       10 * time.Second,
		RequestTimeout:            30 * time.Second,
		MaxFileSize:               0,
		MaxFilesPerRequest:        0,
		StorageMaxRetries:         3,
		StorageRetryDelay:         time.Second,
		CircuitBreakerThreshold:   5,
		CircuitBreakerTimeout:     10 * time.Second,
		CircuitBreakerMaxRequests: 2,
		MaxConcurrent:             10,
		IgnoreMissing:             true,
		CallbackMaxRetries:        3,
		CallbackRetryDelay:        time.Second,
	}

	ctx := context.Background()

	// Create database connection
	db, err := database.New(ctx, cfg, m)
	if err != nil {
		t.Skipf("PostgreSQL not available: %v (run: docker-compose -f docker-compose.test.yml up -d)", err)
	}
	defer db.Close()

	// Create storage provider
	storageBreaker := circuitbreaker.New("storage", cfg, m)
	storageProvider, err := storage.New(ctx, cfg, m, storageBreaker)
	if err != nil {
		t.Fatalf("failed to create storage provider: %v", err)
	}

	// Create verifier and handler
	verifier := auth.NewVerifier(cfg.SigningSecret, cfg.EnforceSigning, m)
	downloadHandler := handlers.NewHandler(
		logger, db, storageProvider, verifier, m,
		false, false, cfg.IgnoreMissing, cfg.MaxConcurrent,
		cfg.CallbackMaxRetries, cfg.CallbackRetryDelay,
	)

	// Test cases
	tests := []struct {
		name           string
		downloadID     string
		wantStatus     int
		wantFiles      []string
		checkZipValid  bool
	}{
		{
			name:          "basic single file download",
			downloadID:    "test-basic",
			wantStatus:    http.StatusOK,
			wantFiles:     []string{"document.txt"},
			checkZipValid: true,
		},
		{
			name:          "multi-file download",
			downloadID:    "test-multi",
			wantStatus:    http.StatusOK,
			wantFiles:     []string{"document.txt", "data.json", "data.csv"},
			checkZipValid: true,
		},
		{
			name:          "all files download",
			downloadID:    "test-all",
			wantStatus:    http.StatusOK,
			wantFiles:     []string{"document.txt", "data.json", "data.csv", "binary.dat"},
			checkZipValid: true,
		},
		{
			name:          "download with missing file (ignore missing)",
			downloadID:    "test-missing",
			wantStatus:    http.StatusOK,
			wantFiles:     []string{"document.txt"}, // nonexistent.txt should be ignored
			checkZipValid: true,
		},
		{
			name:       "nonexistent download",
			downloadID: "nonexistent-id",
			wantStatus: http.StatusNotFound,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req := httptest.NewRequest("GET", "/"+tt.downloadID, nil)
			w := httptest.NewRecorder()

			downloadHandler.Download(w, req)

			if w.Code != tt.wantStatus {
				t.Errorf("status = %d, want %d", w.Code, tt.wantStatus)
				t.Logf("response body: %s", w.Body.String())
				return
			}

			if tt.checkZipValid && w.Code == http.StatusOK {
				// Verify it's a valid ZIP
				zipData := w.Body.Bytes()
				zipReader, err := zip.NewReader(bytes.NewReader(zipData), int64(len(zipData)))
				if err != nil {
					t.Fatalf("invalid ZIP: %v", err)
				}

				// Check file count
				if len(zipReader.File) != len(tt.wantFiles) {
					t.Errorf("ZIP contains %d files, want %d", len(zipReader.File), len(tt.wantFiles))
				}

				// Check file names
				fileMap := make(map[string]bool)
				for _, f := range zipReader.File {
					fileMap[f.Name] = true
				}

				for _, wantFile := range tt.wantFiles {
					if !fileMap[wantFile] {
						t.Errorf("ZIP missing file: %s", wantFile)
					}
				}

				// Verify at least one file has content
				if len(zipReader.File) > 0 {
					rc, err := zipReader.File[0].Open()
					if err != nil {
						t.Fatalf("failed to open file in ZIP: %v", err)
					}
					defer rc.Close()

					content, err := io.ReadAll(rc)
					if err != nil {
						t.Fatalf("failed to read file content: %v", err)
					}

					if len(content) == 0 {
						t.Error("file in ZIP has zero content")
					}
				}
			}
		})
	}
}

func TestIntegration_LocalStorage_MySQL(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping integration test")
	}

// 	logger, _ := zap.NewDevelopment()
	m := metrics.New()

	cfg := &config.Config{
		DBURL:                     "mysql://zipperfly:testpass@tcp(localhost:3306)/zipperfly_test",
		DBEngine:                  "mysql",
		TableName:                 "downloads",
		IDField:                   "id",
		StorageType:               "local",
		StoragePath:               getAbsPath(fixturesDir),
		EnforceSigning:            false,
		SigningSecret:             []byte("test-secret"),
		DatabaseQueryTimeout:      5 * time.Second,
		StorageFetchTimeout:       10 * time.Second,
		StorageMaxRetries:         3,
		StorageRetryDelay:         time.Second,
		CircuitBreakerThreshold:   5,
		CircuitBreakerTimeout:     10 * time.Second,
		CircuitBreakerMaxRequests: 2,
		MaxConcurrent:             10,
		IgnoreMissing:             true,
		CallbackMaxRetries:        3,
		CallbackRetryDelay:        time.Second,
	}

	ctx := context.Background()

	db, err := database.New(ctx, cfg, m)
	if err != nil {
		t.Skipf("MySQL not available: %v (run: docker-compose -f docker-compose.test.yml up -d)", err)
	}
	defer db.Close()

	// Simple smoke test
	record, err := db.GetRecord(ctx, "test-basic")
	if err != nil {
		t.Fatalf("failed to get test record: %v", err)
	}

	if record.ID != "test-basic" {
		t.Errorf("record ID = %s, want test-basic", record.ID)
	}

	if len(record.Objects) == 0 {
		t.Error("record has no objects")
	}
}

func TestIntegration_LocalStorage_Redis(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping integration test")
	}

	logger, _ := zap.NewDevelopment()
	m := metrics.New()

	cfg := &config.Config{
		DBURL:                "redis://localhost:6379/0",
		DBEngine:             "redis",
		KeyPrefix:            "dl:",
		DatabaseQueryTimeout: 5 * time.Second,
	}

	ctx := context.Background()

	db, err := database.New(ctx, cfg, m)
	if err != nil {
		t.Skipf("Redis not available: %v (run: docker-compose -f docker-compose.test.yml up -d)", err)
	}
	defer db.Close()

	// Note: Redis test data needs to be set up separately via Redis CLI or code
	// This is just a connection test
	_ = logger
}

func getAbsPath(relPath string) string {
	abs, err := filepath.Abs(relPath)
	if err != nil {
		// Fallback to current directory + relpath
		wd, _ := os.Getwd()
		return filepath.Join(wd, relPath)
	}
	return abs
}
