package config

import (
	"testing"
	"time"
)

func TestParseDuration(t *testing.T) {
	tests := []struct {
		name         string
		input        string
		defaultValue time.Duration
		want         time.Duration
	}{
		{
			name:         "empty string uses default",
			input:        "",
			defaultValue: 5 * time.Second,
			want:         5 * time.Second,
		},
		{
			name:         "valid duration",
			input:        "10s",
			defaultValue: 5 * time.Second,
			want:         10 * time.Second,
		},
		{
			name:         "minutes",
			input:        "5m",
			defaultValue: 1 * time.Second,
			want:         5 * time.Minute,
		},
		{
			name:         "invalid duration uses default",
			input:        "invalid",
			defaultValue: 3 * time.Second,
			want:         3 * time.Second,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := parseDuration(tt.input, tt.defaultValue)
			if got != tt.want {
				t.Errorf("parseDuration() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestParseBytes(t *testing.T) {
	tests := []struct {
		name         string
		input        string
		defaultValue int64
		want         int64
	}{
		{
			name:         "empty string uses default",
			input:        "",
			defaultValue: 1024,
			want:         1024,
		},
		{
			name:         "plain number",
			input:        "100",
			defaultValue: 0,
			want:         100,
		},
		{
			name:         "kilobytes",
			input:        "10K",
			defaultValue: 0,
			want:         10 * 1024,
		},
		{
			name:         "megabytes",
			input:        "5M",
			defaultValue: 0,
			want:         5 * 1024 * 1024,
		},
		{
			name:         "gigabytes",
			input:        "2G",
			defaultValue: 0,
			want:         2 * 1024 * 1024 * 1024,
		},
		{
			name:         "terabytes",
			input:        "1T",
			defaultValue: 0,
			want:         1024 * 1024 * 1024 * 1024,
		},
		{
			name:         "lowercase suffix",
			input:        "10k",
			defaultValue: 0,
			want:         10 * 1024,
		},
		{
			name:         "invalid input uses default",
			input:        "abc",
			defaultValue: 999,
			want:         999,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := parseBytes(tt.input, tt.defaultValue)
			if got != tt.want {
				t.Errorf("parseBytes() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestParseInt(t *testing.T) {
	tests := []struct {
		name         string
		input        string
		defaultValue int
		want         int
	}{
		{
			name:         "empty string uses default",
			input:        "",
			defaultValue: 10,
			want:         10,
		},
		{
			name:         "valid integer",
			input:        "42",
			defaultValue: 10,
			want:         42,
		},
		{
			name:         "zero",
			input:        "0",
			defaultValue: 10,
			want:         0,
		},
		{
			name:         "invalid input uses default",
			input:        "not-a-number",
			defaultValue: 5,
			want:         5,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := parseInt(tt.input, tt.defaultValue)
			if got != tt.want {
				t.Errorf("parseInt() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestParseStringList(t *testing.T) {
	tests := []struct {
		name  string
		input string
		want  []string
	}{
		{
			name:  "empty string",
			input: "",
			want:  nil,
		},
		{
			name:  "single item",
			input: "foo",
			want:  []string{"foo"},
		},
		{
			name:  "multiple items",
			input: "foo,bar,baz",
			want:  []string{"foo", "bar", "baz"},
		},
		{
			name:  "items with spaces",
			input: "foo, bar , baz",
			want:  []string{"foo", "bar", "baz"},
		},
		{
			name:  "empty items filtered out",
			input: "foo,,bar, ,baz",
			want:  []string{"foo", "bar", "baz"},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := parseStringList(tt.input)
			if len(got) != len(tt.want) {
				t.Errorf("parseStringList() length = %v, want %v", len(got), len(tt.want))
				return
			}
			for i := range got {
				if got[i] != tt.want[i] {
					t.Errorf("parseStringList()[%d] = %v, want %v", i, got[i], tt.want[i])
				}
			}
		})
	}
}
